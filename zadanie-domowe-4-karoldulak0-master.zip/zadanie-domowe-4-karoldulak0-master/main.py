import numpy as np
import pickle

from typing import Union, List, Tuple
from numpy.linalg import inv

def random_matrix_Ab(m:int):
    """Funkcja tworząca zestaw składający się z macierzy A (m,m) i wektora b (m,)  zawierających losowe wartości
    Parameters:
    m(int): rozmiar macierzy
    Results:
    (np.ndarray, np.ndarray): macierz o rozmiarze (m,m) i wektorem (m,)
                Jeżeli dane wejściowe niepoprawne funkcja zwraca None
    """
    if isinstance(m , int) and m >= 1 :
      A = np.random.rand(m,m)
      b = np.random.rand(m,)

      return A , b 

    else:
      return None 

def residual_norm(A:np.ndarray,x:np.ndarray, b:np.ndarray):
    """Funkcja obliczająca normę residuum dla równania postaci:
    Ax = b

      Parameters:
      A: macierz A (m,m) zawierająca współczynniki równania 
      x: wektor x (m.) zawierający rozwiązania równania 
      b: wektor b (m,) zawierający współczynniki po prawej stronie równania

      Results:
      (float)- wartość normy residuom dla podanych parametrów"""

    if isinstance(A , np.ndarray) and isinstance(x , np.ndarray) and isinstance(b , np.ndarray):
          if A.shape[0] == x.shape[0] and A.shape[0] == A.shape[1] and A.shape[0] == b.shape[0]:
             
              Ax = np.matmul(A,x)
              k = b - Ax
              return np.linalg.norm(k)
            
          else:
            return None
    else: 
      return None
