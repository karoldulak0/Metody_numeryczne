import numpy as np
import scipy as sp
from scipy import linalg
from  datetime import datetime
import pickle

from typing import Union, List, Tuple

'''
Do celów testowych dla elementów losowych uzywaj seed = 24122022
'''

def random_matrix_by_egval(egval_vec: np.ndarray):
    """Funkcja z pierwszego zadania domowego
    Parameters:
    egval_vec : wetkor wartości własnych
    Results:
    np.ndarray: losowa macierza o zadanych wartościach własnych 
                Jeżeli dane wejściowe niepoprawne funkcja zwraca None
    """
    if isinstance(egval_vec , (np.ndarray, List)):
        if isinstance(egval_vec[0] , str):
            return None 
        np.random.seed(24122022)
        J = np.diag(egval_vec)
        n = len(egval_vec)  
        P = np.random.rand(n,n)      
        Pinv = np.linalg.inv(P)   
        A = P@J@Pinv
        return A
    else:
        return None
     

def frob_a(coef_vec: np.ndarray):
    """Funkcja z drugiego zadania domowego
    Parameters:
    coef_vec : wetkor wartości wspołczynników
    Results:
    np.ndarray: macierza Frobeniusa o zadanych wartościach współczynników wielomianu 
                Jeżeli dane wejściowe niepoprawne funkcja zwraca None
    """
    if isinstance(coef_vec , np.ndarray):
        
    #wektor coef_vect juz jest tym prawdziwym i wystarczy tylko zrobic flipa i dac na koniec i dac te jedynki 
        minus = np.negative(coef_vec)
        new = np.flip(minus)
        n = len(new)
        F = np.eye(n)
        first_col = np.zeros((n,1))
        F1 = np.hstack((first_col,F))
        add = np.append(new , [0])
        F1[n-1] = add 
        F2 = np.delete(F1 , -1 ,axis = 1 )   
        return F2
    else:
        return None 
  