# -*- coding: utf-8 -*-

import pytest
import main
import pickle
import math
import numpy as np

from typing import Union, List, Tuple

expected = pickle.load(open('expected','rb'))

result_spare_matrix_Abt = expected['spare_matrix_Abt']

@pytest.mark.parametrize("m,n,result", result_spare_matrix_Abt)
def test_spare_matrix_Abt(m:int,n:int, result):
    if result is None:
        assert main.spare_matrix_Abt(m,n) is None, 'Spodziewany wynik: {0}, aktualny {1}. Błedy wejścia.'.format(result, main.spare_matrix_Abt(m,n))
    else:
        A, b = main.spare_matrix_Abt(int(m),int(n))
        assert A == pytest.approx(result[0]) and b == pytest.approx(result[1]), 'Spodziewany wynik: {0}, aktualny {1}. Błedy wejścia.'.format(result, main.spare_matrix_Abt(m,n))
