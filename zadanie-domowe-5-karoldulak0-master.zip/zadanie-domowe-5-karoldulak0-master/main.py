import numpy as np
import scipy as sp
from scipy import linalg
from  datetime import datetime
import pickle

from typing import Union, List, Tuple


def spare_matrix_Abt(m: int,n: int):
    """Funkcja tworząca zestaw składający się z macierzy A (m,n), wektora b (m,)  i pomocniczego wektora t (m,) zawierających losowe wartości
    Parameters:
    m(int): ilość wierszy macierzy A
    n(int): ilość kolumn macierzy A
    Results:
    (np.ndarray, np.ndarray): macierz o rozmiarze (m,n) i wektorem (m,)
                Jeżeli dane wejściowe niepoprawne funkcja zwraca None
    """
    if isinstance(m,int) and m > 0 and isinstance(n,int) and n >0: 
        temp = np.linspace(0, 1, m) #tworze wektor t od 0 do 1 o ilosci elementow m 
        t = np.transpose(temp) #aby był size = (m,)
        Atemp = np.vander(t, n) #macierz vandera - pierwsza kolumna t^n-1 druga t^n-2 itd 
        b = np.cos(4*t)
        A = np.fliplr(Atemp) #odwrocenie wzdluz srodkowej osi 
        return A , b 
    
    else: 
        return None

